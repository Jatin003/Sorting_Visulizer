const Colors = {
  default: "#ffffff",
  primary: "#df6e8b",
  secondary: "#1583C8",
  alt: "#01345b",
  highlight: "#15C1FB",
};

export default Colors;
